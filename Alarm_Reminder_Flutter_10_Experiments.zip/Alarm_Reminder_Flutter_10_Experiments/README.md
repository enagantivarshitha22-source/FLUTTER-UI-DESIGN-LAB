# Alarm Reminder — Flutter Lab (10 Experiments)

> Student details: replace the placeholders below before submission.

- **Student name:** [Your Name]
- **Roll number:** [Your Roll Number]
- **Class/Section:** [Your Class]
- **Subject:** UI Design using Flutter (CS506PC)
- **Project title:** Alarm Reminder App

## Experiments and progress

| No. | Experiment | Status | Output screenshot |
|---:|---|---|---|
| 1 | Dart Basics with Reminder Data | To run and capture | `Experiment-01-Dart-Basics/output/` |
| 2 | Widgets and Layouts | To run and capture | `Experiment-02-Widgets-and-Layouts/output/` |
| 3 | Row and Column | To run and capture | `Experiment-03-Row-and-Column/output/` |
| 4 | Input Widgets | To run and capture | `Experiment-04-Input-Widgets/output/` |
| 5 | Forms and Validation | To run and capture | `Experiment-05-Forms/output/` |
| 6 | Navigation Between Screens | To run and capture | `Experiment-06-Navigation/output/` |
| 7 | Lists and Cards with Delete | To run and capture | `Experiment-07-Lists-and-Cards/output/` |
| 8 | State Management with setState | To run and capture | `Experiment-08-State-Management/output/` |
| 9 | Responsive User Interface | To run and capture | `Experiment-09-Responsive-UI/output/` |
| 10 | Alarm Reminder Mini Project | To run and capture | `Experiment-10-Alarm-Reminder-Mini-Project/output/` |

## Syllabus mapping
These are suggested experiment topics based on common Flutter UI concepts. **Confirm the titles and order against your lecturer's official list** before final submission.

## How to run without VS Code (Windows CMD)

1. Extract this ZIP.
2. Open Command Prompt.
3. Change directory into one experiment, for example:
   `cd /d "C:\path\to\Alarm_Reminder_Flutter_10_Experiments\Experiment-10-Alarm-Reminder-Mini-Project"`
4. Run:
   `flutter pub get`
5. Run in Chrome:
   `flutter run -d chrome`

Repeat with another experiment folder to run that experiment. These are separate small Flutter projects and do not need VS Code.

## Screenshots
After each experiment runs, capture the Chrome output with `Windows + Shift + S` and save the image in that experiment's `output` folder.

## GitHub submission reminder
Create one public repository, upload this root folder and its 10 experiment folders, and update this README. Commit and push after each experiment as required by your lecturer. Submit the repository link through the registration form.

## Important limitations
These sample experiments demonstrate UI and in-memory reminder actions. The mini project does not yet schedule operating-system notifications or persist reminders after the app closes. Add those features only if your official requirements demand them.
